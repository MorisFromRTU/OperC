package com.bsbo_05_19.martirosyan.task;

public class Feline{
    public String name;
    public int age;
    public boolean dangerous;
    public Feline(String Name, int Age, boolean Dangerous){
        name = Name;
        age = Age;
        dangerous = Dangerous;
    }
    public void show(){
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("this feline is dangerous " + dangerous);
    }
}