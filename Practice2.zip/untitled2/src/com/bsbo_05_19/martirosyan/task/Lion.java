package com.bsbo_05_19.martirosyan.task;



public class Lion extends Feline {
    String sex;

    public Lion(String Name, int Age, boolean Dangerous, String Sex){
        super(Name, Age, Dangerous);
        sex = Sex;
    }

    public void show(){
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("this feline is dangerous: " + dangerous);
        System.out.println("sex: " + sex);
    }
}