package com.bsbo_05_19.martirosyan.task;

public class Tiger extends Feline{
    String type;

    public Tiger(String Name, int Age, boolean Dangerous, String Type){
        super(Name, Age, Dangerous);
        type = Type;
    }

    public void show(){
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("this feline is dangerous: " + dangerous);
        System.out.println("type of this tiger: " + type);
    }
}