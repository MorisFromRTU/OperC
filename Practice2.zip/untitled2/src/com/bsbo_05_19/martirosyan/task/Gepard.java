package com.bsbo_05_19.martirosyan.task;

public class Gepard extends Feline{
    String spot_size;

    public Gepard(String Name, int Age, boolean Dangerous, String Spot_size){
        super(Name, Age, Dangerous);
        spot_size = Spot_size;
    }

    public void show(){
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("this feline is dangerous: " + dangerous);
        System.out.println("Size of spots: " + spot_size);
    }
}