package com.bsbo_05_19.martirosyan;
import java.util.Scanner;

import com.bsbo_05_19.martirosyan.task.*;
import com.bsbo_05_19.martirosyan.task2.*;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int num = Integer.parseInt(scanner.nextLine());
        switch (num){
            case 1:Lion king = new Lion("King",8, false,"man");
                king.show();
                break;
            case 2: Cats c_daughter = new Cats("Kitty", 2, false, null, null);
                    c_daughter.show();
                    Cats c_mother = new Cats("Mary", 7, false, null, null);
                    c_mother.show();
                    System.out.println("Let's check other family");
                    Cats grandfather = new Cats("Johny", 15, false, null, null);
                    grandfather.show();
                    Cats grandmother = new Cats("Elizabet", 12, false,null,null );
                    grandmother.show();
                    Cats father = new Cats("Karl", 12, false, null, grandfather);
                    father.printINfo();
                    Cats mother = new Cats("Emma", 10, false, null, grandfather);
                    mother.printINfo();
                    Cats son = new Cats("Ben", 4, false, mother, father);
                    son.show();
                    Cats daughter = new Cats("Alice", 3, false, mother, father);
                    daughter.show();
                    break;
            case 3:
                break;

        }



    }
}
