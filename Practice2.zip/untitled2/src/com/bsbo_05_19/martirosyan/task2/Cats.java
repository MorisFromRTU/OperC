package com.bsbo_05_19.martirosyan.task2;
import com.bsbo_05_19.martirosyan.task.*;
public class Cats extends Feline {
    public Cats mother_cat;
    public Cats father_cat;

    public Cats(String Name, int Age, boolean Dangerous, Cats mother_cat, Cats father_cat) {
        super(Name, Age, Dangerous);
        this.mother_cat = mother_cat;
        this.father_cat = father_cat;
    }


    public void show() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("this feline is dangerous: " + dangerous);
       // System.out.println("this feline is dangerous: " + dangerous);
        //System.out.println("father: " + father_cat);
    }

    public String printINfo() {
        StringBuilder info = new StringBuilder();
        info.append("My name is").append(name);

        if (father_cat != null && mother_cat != null) {
            info.append(father_cat.name)
                    .append(mother_cat.name);
        }
        return info.toString();
    }
}
