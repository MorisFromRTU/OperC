package com.pr3.BSBO_05_19_Martirosyan_Moris;
import java.util.Scanner;
import java.io.*;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Input a number of task: ");
        int i = in.nextInt();
	switch(i) {
            case 1:
                String t1 = ("Иванов");
                String t2 = ("Иван");
                String t3 = ("Иванович");

               String result = t1.concat(t2).concat(t3);
                System.out.println( result);
                break;
            case 2:
                    String name = "Петя";
                    int age = 27;

                    System.out.println("Меня зовут "+ name + ", мне " + Integer.toString(age) + " лет");
                    break;
            case 3:
                Scanner il = new Scanner(System.in);
                System.out.print("Введите строчку: ");
                String j = il.nextLine();
                System.out.println("Длина введенной вами строки: ");
                System.out.println(j.length());
                System.out.println("Введенная вами строка, посимвольно: ");
                for(int q=0; q<j.length(); q++) {
                    System.out.println( j.charAt(q));
                }
                break;
            case 4:
                Scanner ip = new Scanner(System.in);
                System.out.print("Введите строчку: ");
                String k = ip.nextLine();
                System.out.print("Строка, где символы 'а' заменены на 'о': ");
                System.out.println( k.replace('а', 'о'));
                System.out.print("Строка, где подстрока 'чиво' заменена на 'что': ");
                System.out.println( k.replace("чиво", "что"));

                break;
            case 5:
                Scanner iy = new Scanner(System.in);
                System.out.print("Введите строчку: ");
                String w = iy.nextLine();
                
                }

                }



        }


