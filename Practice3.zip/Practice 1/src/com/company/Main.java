package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Input a number of task: ");
        int i = in.nextInt();
        switch(i) {
            case 1:
                String t1 = ("Иванов");
                String t2 = ("Иван");
                String t3 = ("Иванович");

                String result = t1.concat(t2).concat(t3);
                System.out.println( result);
                break;
            case 2:
                String name = "Петя";
                int age = 27;

                System.out.println("Меня зовут "+ name + ", мне " + age + " лет");
                break;
            case 3:
                Scanner il = new Scanner(System.in);
                System.out.print("Введите строчку: ");
                String j = il.nextLine();
                System.out.println("Длина введенной вами строки: ");
                System.out.println(j.length());
                System.out.println("Введенная вами строка, посимвольно: ");
                for(int q=0; q<j.length(); q++) {
                    System.out.println( j.charAt(q));
                }
                break;
            case 4:
                Scanner ip = new Scanner(System.in);
                System.out.print("Введите строчку: ");
                String k = ip.nextLine();
                System.out.print("Строка, где символы 'а' заменены на 'о': ");
                System.out.println( k.replace('а', 'о'));
                System.out.print("Строка, где подстрока 'чиво' заменена на 'что': ");
                System.out.println( k.replace("чиво", "что"));

                break;
            case 5:
                Scanner iy = new Scanner(System.in);
                System.out.print("Введите строчку: ");
                String w = iy.nextLine();

                System.out.println("В нижнем регистре:  "+ w.toLowerCase());
                System.out.println("В верхнем регистре:  " + w.toUpperCase());
                break;
            case 6:Scanner i2 = new Scanner(System.in);
                System.out.print("Введите строчку: ");
                String r = i2.nextLine();
                char [] bykvi = r.toCharArray();

                for (int u=r.length()-1; u>=0; u--) {
                    System.out.println(bykvi[u]);
                }
                break;
            case 7:
                System.out.println("Вводите числа или программа остановится");
                Scanner io = new Scanner(System.in);
                ArrayList<Float> floats = new ArrayList<Float>();
                try {
                    while (true) {
                        floats.add(in.nextFloat());

                    }
                }catch (Exception ex){
                    for (Float var: floats
                    ) {
                        System.out.println(var);
                    }
                }
                System.out.println(" ");


        case 8:
                try {
                    String s = null;
                    String m = s.toLowerCase();
                }catch (Exception e){
                    System.out.println(e.toString());
                }

                try {
                    int[] m = new int[2];
                    m[8] = 5;
                }catch (Exception e){
                    System.out.println(e.toString());
                }

                try {
                    ArrayList<String> list = new ArrayList<String>();
                    String s = list.get(18);
                }catch (Exception e){
                    System.out.println(e.toString());

            }
        }

    }
}
