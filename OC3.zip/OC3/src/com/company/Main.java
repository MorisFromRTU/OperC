package com.company;

import javax.print.attribute.IntegerSyntax;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.*;


public class Main {
        public static BlockingQueue<Integer> queue = new ArrayBlockingQueue<Integer>(200);

    public static void main(String[] args)
            throws InterruptedException {
        Random rand = new Random();
        for (int i = 0; i < 200; i++) {
           queue.add(rand.nextInt(100));
        }

        // Create producer thread 
        Thread Producer = new Thread(new Producer());
        Thread Producer2 = new Thread(new Producer());
        Thread Producer3 = new Thread(new Producer());
        Thread Consumer = new Thread(new Consumer());
        Thread Consumer2 = new Thread(new Consumer());


        // Start both threads 
        Producer.start();
        Producer2.start();
        Producer3.start();
        Consumer.start();
        Consumer2.start();

        // t1 finishes before t2 
     /*   Producer.join();
        Producer2.join();
        Producer3.join();
        Consumer.join();
        Consumer2.join();*/


        Scanner scanner = new Scanner(System.in);
        String input;
        while (true){
            input = scanner.next();
            if(input.equalsIgnoreCase("q")){
                Producer.stop();
                Producer2.stop();
                Producer3.stop();
                while (queue.size()!=0) {

                }
                System.out.println( "All of products were consumed! ");
                System.exit(0);

            }
        }
    }

    public static class Producer extends Thread {

        public void run() {
            int value = 0;
            while (true) {
                synchronized (this) {
                    while (Main.queue.size() >= 100) {
                      /*  try {
                            wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }*/
                    }
                    System.out.println("One of Producers produced: "
                            + value + " Elements in the queue: " + Main.queue.size());

                    Main.queue.add(value++);
                    notify();
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        }
    }

    public static class Consumer extends Thread {
        public void run() {
            while (true) {
                synchronized (this) {

                    while (Main.queue.size() == 0) {
                       /* try {
                            wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }*/
                    }
                    int val = Main.queue.poll();
                    System.out.println( "One of consumers consumed: "
                            + val + " Elements in the queue: " + Main.queue.size());
                    notify();
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                       /* while (Main.queue.size() <= 80){
                        }*/
                }
            }
        }
    }

} 