package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
six();
    }

    public static void first() {
        double[] array = new double[10];
        double imax = 0;
        double imin = 1;
        double all = 0;
        double middle = 0;
        for (int i = 0; i < array.length; i++) {
            array[i] =  (Math.random());
        //    System.out.println(array[i]);
        }
        for (int i = 0; i < array.length; i++) {
           if (array[i]>imax) {
           imax = array[i];
           }
           if (array[i]<imin){
               imin = array[i];
           }
            all += array[i];
        }
         middle = all / array.length;

        System.out.println("Минимальное значение " + imin);
        System.out.println("Максимальное значение " + imax);
        System.out.println("Среднее значение " + middle);
    }
    public static void second(){
        Scanner in = new Scanner(System.in);
        System.out.print("Input number: ");
        int n = in.nextInt();
        if (n==0) System.out.print("Error");
        if ((n<=100) && (n>0)) {
        if ((n == 12) || (n<3) ) {
            System.out.print("Winter");
        }
        if ((n>2) && (n<6)) {
                System.out.print("Spring");
        }
        if ((n>5) && (n<9)) {
                System.out.print("Summer");
        }
        if ((n>8) && (n<12)) {
                System.out.print("Autumn");
        }

        else   System.out.print("Error");

        }
        }
    public static void three(){
        Scanner in = new Scanner(System.in);
        System.out.print("Input number: ");
        int n = in.nextInt();
        while (n%2 == 0) {
        n = n / 2;
        }

        if (n == 1)
            System.out.print("YES YES YES ");
        else
            System.out.print("NO NO NO");
    }
    public static void four(){
        Scanner in = new Scanner(System.in);
        System.out.print("Input number: ");
        int n = in.nextInt();
        long fac = 1;
        int [] mas = new int [n+1];
        for (int i=1; i<=n; i++){
            mas[i] = i;
        }
        for (int i=1; i<=n; i++ ){
            fac= fac * mas[i];
        }
        System.out.print(fac);
    }
    public static void five(){
        Scanner in = new Scanner(System.in);
        System.out.print("Input number: ");
        int n = in.nextInt();
        in.close();

         int n2 = n;
         int z1 =0, z2 = 0, z3 =0, z4=0;
         while (z1==z2 || z1 == z3 || z1== z4 || z2 == z3 || z2 == z4 || z3 == z4 || n2 == n) {
         n2=n2+1;
         z1 = n2 % 10;
         z2 = n2 / 10 % 10;
         z3 = n2 / 100 % 10;
         z4 = n2 / 1000 % 10;
         }
            System.out.print(n2);

            }
    public static void six(){
        int [] massive = new int[11];
        massive[0] = 1;
        massive [1] = 1;
        for (int i=2; i< 11; i++){
            massive [i] = massive[i-2]+ massive[i-1];
            }
        for (int i=0; i <11; i++){
            System.out.print(massive[i]+" ");
        }
        }

        }






